﻿using EnviosWebApi.Models;

namespace EnviosWebApi.Repository
{
    public interface IEnvioRepository
    {
        List<TEnvio> GetBetween(DateTime fecha1, DateTime fecha2);

        bool Create(TEnvio oEnvio);

        bool Delete(int id);

    }
}
