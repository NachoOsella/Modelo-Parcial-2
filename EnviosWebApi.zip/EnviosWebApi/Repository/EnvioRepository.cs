﻿using EnviosWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace EnviosWebApi.Repository
{
    public class EnvioRepository : IEnvioRepository
    {
        private EnviosContext _context;

        public EnvioRepository(EnviosContext context) 
        {
            _context = context;
        }

        public bool Create(TEnvio oEnvio)
        {
            _context.TEnvios.Add(oEnvio);
            return _context.SaveChanges() > 0;
        }

        public bool Delete(int id)
        {
            var envioBorrar = _context.TEnvios.Find(id);

            if(envioBorrar != null)
            {
                envioBorrar.Estado = "Cancelado";
                _context.TEnvios.Update(envioBorrar);
                return _context.SaveChanges() > 0;
            }
            else
            {
                return false;
            }
        }

        public List<TEnvio> GetBetween(DateTime fecha1, DateTime fecha2)
        {
            return _context.TEnvios.Where(x => x.FechaEnvio >= fecha1 && x.FechaEnvio <= fecha2).ToList();
        }
    }
}
