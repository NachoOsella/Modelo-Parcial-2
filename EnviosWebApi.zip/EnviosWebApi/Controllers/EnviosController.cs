﻿using EnviosWebApi.Models;
using EnviosWebApi.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EnviosWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnviosController : ControllerBase
    {
        private IEnvioRepository _envioRepository;

        public EnviosController (IEnvioRepository envioRepository)
        {
            _envioRepository = envioRepository;
        }



        // GET: api/<EnviosController>
        [HttpGet]
        public IActionResult GetBetween(DateTime fecha1, DateTime fecha2)
        {
            try
            {
                var envios = _envioRepository.GetBetween(fecha1, fecha2);
                if (envios == null) 
                {
                    return BadRequest("No existen envios entre esas fechas");
                }
                else
                {
                    return Ok(envios);
                }
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        

        // POST api/<EnviosController>
        [HttpPost]
        public IActionResult Post([FromBody] TEnvio oEnvio)
        {
            try
            {
                if (IsValid(oEnvio))
                {
                    return Ok(_envioRepository.Create(oEnvio));
                }
                else
                {
                    return BadRequest("Datos no validos...");
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "Error interno...");
            }
        }

        private bool IsValid(TEnvio oEnvio)
        {
            return !string.IsNullOrEmpty(oEnvio.Direccion) &&
                   !string.IsNullOrEmpty(oEnvio.Estado) && !string.IsNullOrEmpty(oEnvio.DniCliente) &&
                   oEnvio.IdEmpresa > 0;
        }



        // PUT api/<EnviosController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                return Ok(_envioRepository.Delete(id));
            }
            catch (Exception)
            {
                return StatusCode(500, "Error interno...");
            }
        }

    }
}
